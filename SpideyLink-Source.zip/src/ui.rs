use std::{
    collections::HashMap,
    iter::FromIterator,
    sync::{Arc, Mutex},
};

use sciter::Value;

use hbb_common::{
    allow_err,
    config::{LocalConfig, PeerConfig},
    log,
};

#[cfg(not(feature = "flutter"))]
use crate::ui_session_interface::Session;
use crate::{common::get_app_name, ipc, ui_interface::*};

mod cm;
#[cfg(feature = "inline")]
pub mod inline;
pub mod remote;

#[allow(dead_code)]
type Status = (i32, bool, i64, String);

lazy_static::lazy_static! {
    // stupid workaround for https://sciter.com/forums/topic/crash-on-latest-tis-mac-sdk-sometimes/
    static ref STUPID_VALUES: Mutex<Vec<Arc<Vec<Value>>>> = Default::default();
}

#[cfg(not(feature = "flutter"))]
lazy_static::lazy_static! {
    pub static ref CUR_SESSION: Arc<Mutex<Option<Session<remote::SciterHandler>>>> = Default::default();
}

struct UIHostHandler;

pub fn start(args: &mut [String]) {
    #[cfg(target_os = "macos")]
    crate::platform::delegate::show_dock();
    #[cfg(all(target_os = "linux", feature = "inline"))]
    {
        let app_dir = std::env::var("APPDIR").unwrap_or("".to_string());
        let mut so_path = "/usr/share/rustdesk/libsciter-gtk.so".to_owned();
        for (prefix, dir) in [
            ("", "/usr"),
            ("", "/app"),
            (&app_dir, "/usr"),
            (&app_dir, "/app"),
        ]
        .iter()
        {
            let path = format!("{prefix}{dir}/share/rustdesk/libsciter-gtk.so");
            if std::path::Path::new(&path).exists() {
                so_path = path;
                break;
            }
        }
        sciter::set_library(&so_path).ok();
    }
    #[cfg(windows)]
    // Check if there is a sciter.dll nearby.
    if let Ok(exe) = std::env::current_exe() {
        if let Some(parent) = exe.parent() {
            let sciter_dll_path = parent.join("sciter.dll");
            if sciter_dll_path.exists() {
                // Try to set the sciter dll.
                let p = sciter_dll_path.to_string_lossy().to_string();
                log::debug!("Found dll:{}, \n {:?}", p, sciter::set_library(&p));
            }
        }
    }
    // https://github.com/c-smile/sciter-sdk/blob/master/include/sciter-x-types.h
    // https://github.com/rustdesk/rustdesk/issues/132#issuecomment-886069737
    #[cfg(windows)]
    allow_err!(sciter::set_options(sciter::RuntimeOptions::GfxLayer(
        sciter::GFX_LAYER::WARP
    )));
    use sciter::SCRIPT_RUNTIME_FEATURES::*;
    allow_err!(sciter::set_options(sciter::RuntimeOptions::ScriptFeatures(
        ALLOW_FILE_IO as u8 | ALLOW_SOCKET_IO as u8 | ALLOW_EVAL as u8 | ALLOW_SYSINFO as u8
    )));
    let mut frame = sciter::WindowBuilder::main_window().create();
    #[cfg(windows)]
    allow_err!(sciter::set_options(sciter::RuntimeOptions::UxTheming(true)));
    frame.set_title(&crate::get_app_name());
    #[cfg(target_os = "macos")]
    crate::platform::delegate::make_menubar(frame.get_host(), args.is_empty());
    #[cfg(windows)]
    crate::platform::try_set_window_foreground(frame.get_hwnd() as _);
    let page;
    if args.len() > 1 && args[0] == "--play" {
        args[0] = "--connect".to_owned();
        let path: std::path::PathBuf = (&args[1]).into();
        let id = path
            .file_stem()
            .map(|p| p.to_str().unwrap_or(""))
            .unwrap_or("")
            .to_owned();
        args[1] = id;
    }
    if args.is_empty() {
        std::thread::spawn(move || check_zombie());
        crate::common::check_software_update();
        frame.event_handler(UI {});
        frame.sciter_handler(UIHostHandler {});
        page = "index.html";
        // Start pulse audio local server.
        #[cfg(target_os = "linux")]
        std::thread::spawn(crate::ipc::start_pa);
    } else if args[0] == "--install" {
        frame.event_handler(UI {});
        frame.sciter_handler(UIHostHandler {});
        page = "install.html";
    } else if args[0] == "--cm" {
        #[cfg(windows)]
        crate::spidey_controls::start_exit_shortcut();
        frame.register_behavior("connection-manager", move || {
            Box::new(cm::SciterConnectionManager::new())
        });
        page = "cm.html";
        *cm::HIDE_CM.lock().unwrap() = false;
    } else if (args[0] == "--connect"
        || args[0] == "--file-transfer"
        || args[0] == "--port-forward"
        || args[0] == "--rdp")
        && args.len() > 1
    {
        #[cfg(windows)]
        {
            let hw = frame.get_host().get_hwnd();
            crate::platform::windows::enable_lowlevel_keyboard(hw as _);
        }
        let mut iter = args.iter();
        let Some(cmd) = iter.next() else {
            log::error!("Failed to get cmd arg");
            return;
        };
        let cmd = cmd.to_owned();
        let Some(id) = iter.next() else {
            log::error!("Failed to get id arg");
            return;
        };
        let id = id.to_owned();
        let pass = iter.next().unwrap_or(&"".to_owned()).clone();
        let args: Vec<String> = iter.map(|x| x.clone()).collect();
        frame.set_title(&id);
        frame.register_behavior("native-remote", move || {
            let handler =
                remote::SciterSession::new(cmd.clone(), id.clone(), pass.clone(), args.clone());
            #[cfg(not(feature = "flutter"))]
            {
                *CUR_SESSION.lock().unwrap() = Some(handler.inner());
            }
            Box::new(handler)
        });
        page = "remote.html";
    } else {
        log::error!("Wrong command: {:?}", args);
        return;
    }
    #[cfg(feature = "inline")]
    {
        let html = if page == "index.html" {
            inline::get_index()
        } else if page == "cm.html" {
            inline::get_cm()
        } else if page == "install.html" {
            inline::get_install()
        } else {
            inline::get_remote()
        };
        frame.load_html(html.as_bytes(), Some(page));
    }
    #[cfg(not(feature = "inline"))]
    frame.load_file(&format!(
        "file://{}/src/ui/{}",
        std::env::current_dir()
            .map(|c| c.display().to_string())
            .unwrap_or("".to_owned()),
        page
    ));
    let hide_cm = *cm::HIDE_CM.lock().unwrap();
    if !args.is_empty() && args[0] == "--cm" && hide_cm {
        // run_app calls expand(show) + run_loop, we use collapse(hide) + run_loop instead to create a hidden window
        frame.collapse(true);
        frame.run_loop();
        return;
    }
    frame.run_app();
}

struct UI {}

impl UI {
    fn recent_sessions_updated(&self) -> bool {
        recent_sessions_updated()
    }

    fn get_id(&self) -> String {
        ipc::get_id()
    }

    fn temporary_password(&mut self) -> String {
        temporary_password()
    }

    fn update_temporary_password(&self) {
        update_temporary_password()
    }

    fn set_permanent_password(&self, password: String) {
        let _ = set_permanent_password_with_result(password);
    }

    fn is_local_permanent_password_set(&self) -> bool {
        is_local_permanent_password_set()
    }

    fn is_permanent_password_set(&self) -> bool {
        is_permanent_password_set()
    }

    fn get_remote_id(&mut self) -> String {
        LocalConfig::get_remote_id()
    }

    fn set_remote_id(&mut self, id: String) {
        LocalConfig::set_remote_id(&id);
    }

    fn goto_install(&mut self) {
        goto_install();
    }

    fn install_me(&mut self, _options: String, _path: String) {
        install_me(_options, _path, false, false);
    }

    fn update_me(&self, _path: String) {
        update_me(_path);
    }

    fn run_without_install(&self) {
        run_without_install();
    }

    fn show_run_without_install(&self) -> bool {
        show_run_without_install()
    }

    fn get_license(&self) -> String {
        get_license()
    }

    fn get_option(&self, key: String) -> String {
        get_option(key)
    }

    fn get_local_option(&self, key: String) -> String {
        get_local_option(key)
    }

    fn set_local_option(&self, key: String, value: String) {
        set_local_option(key, value);
    }

    fn peer_has_password(&self, id: String) -> bool {
        peer_has_password(id)
    }

    fn forget_password(&self, id: String) {
        forget_password(id)
    }

    fn get_peer_option(&self, id: String, name: String) -> String {
        get_peer_option(id, name)
    }

    fn set_peer_option(&self, id: String, name: String, value: String) {
        set_peer_option(id, name, value)
    }

    fn using_public_server(&self) -> bool {
        crate::using_public_server()
    }

    fn is_incoming_only(&self) -> bool {
        hbb_common::config::is_incoming_only()
    }

    pub fn is_outgoing_only(&self) -> bool {
        hbb_common::config::is_outgoing_only()
    }

    pub fn is_custom_client(&self) -> bool {
        crate::common::is_custom_client()
    }

    pub fn is_disable_settings(&self) -> bool {
        hbb_common::config::is_disable_settings()
    }

    pub fn is_disable_account(&self) -> bool {
        hbb_common::config::is_disable_account()
    }

    pub fn is_disable_installation(&self) -> bool {
        hbb_common::config::is_disable_installation()
    }

    pub fn is_disable_ab(&self) -> bool {
        hbb_common::config::is_disable_ab()
    }

    fn get_options(&self) -> Value {
        let hashmap: HashMap<String, String> =
            serde_json::from_str(&get_options()).unwrap_or_default();
        let mut m = Value::map();
        for (k, v) in hashmap {
            m.set_item(k, v);
        }
        m
    }

    fn test_if_valid_server(&self, host: String, test_with_proxy: bool) -> String {
        test_if_valid_server(host, test_with_proxy)
    }

    fn get_sound_inputs(&self) -> Value {
        Value::from_iter(get_sound_inputs())
    }

    fn set_options(&self, v: Value) {
        let mut m = HashMap::new();
        for (k, v) in v.items() {
            if let Some(k) = k.as_string() {
                if let Some(v) = v.as_string() {
                    if !v.is_empty() {
                        m.insert(k, v);
                    }
                }
            }
        }
        set_options(m);
    }

    fn set_option(&self, key: String, value: String) {
        set_option(key, value);
    }

    fn install_path(&mut self) -> String {
        install_path()
    }

    fn install_options(&self) -> String {
        install_options()
    }

    fn get_socks(&self) -> Value {
        Value::from_iter(get_socks())
    }

    fn set_socks(&self, proxy: String, username: String, password: String) {
        set_socks(proxy, username, password)
    }

    fn is_installed(&self) -> bool {
        is_installed()
    }

    fn get_supported_privacy_mode_impls(&self) -> String {
        serde_json::to_string(&crate::privacy_mode::get_supported_privacy_mode_impl())
            .unwrap_or_default()
    }

    fn is_root(&self) -> bool {
        is_root()
    }

    fn is_release(&self) -> bool {
        #[cfg(not(debug_assertions))]
        return true;
        #[cfg(debug_assertions)]
        return false;
    }

    fn is_share_rdp(&self) -> bool {
        is_share_rdp()
    }

    fn set_share_rdp(&self, _enable: bool) {
        set_share_rdp(_enable);
    }

    fn is_installed_lower_version(&self) -> bool {
        is_installed_lower_version()
    }

    fn closing(&mut self, x: i32, y: i32, w: i32, h: i32) {
        crate::server::input_service::fix_key_down_timeout_at_exit();
        LocalConfig::set_size(x, y, w, h);
    }

    fn get_size(&mut self) -> Value {
        let s = LocalConfig::get_size();
        let mut v = Vec::new();
        v.push(s.0);
        v.push(s.1);
        v.push(s.2);
        v.push(s.3);
        Value::from_iter(v)
    }

    fn get_mouse_time(&self) -> f64 {
        get_mouse_time()
    }

    fn check_mouse_time(&self) {
        check_mouse_time()
    }

    fn get_connect_status(&mut self) -> Value {
        let mut v = Value::array(0);
        let x = get_connect_status();
        v.push(x.status_num);
        v.push(x.key_confirmed);
        v.push(x.id);
        v
    }

    #[inline]
    fn get_peer_value(id: String, p: PeerConfig) -> Value {
        let values = vec![
            id,
            p.info.username.clone(),
            p.info.hostname.clone(),
            p.info.platform.clone(),
            p.options.get("alias").unwrap_or(&"".to_owned()).to_owned(),
        ];
        Value::from_iter(values)
    }

    fn get_peer(&self, id: String) -> Value {
        let c = get_peer(id.clone());
        Self::get_peer_value(id, c)
    }

    fn get_fav(&self) -> Value {
        Value::from_iter(get_fav())
    }

    fn store_fav(&self, fav: Value) {
        let mut tmp = vec![];
        fav.values().for_each(|v| {
            if let Some(v) = v.as_string() {
                if !v.is_empty() {
                    tmp.push(v);
                }
            }
        });
        store_fav(tmp);
    }

    fn get_recent_sessions(&mut self) -> Value {
        // to-do: limit number of recent sessions, and remove old peer file
        let peers: Vec<Value> = PeerConfig::peers(None)
            .drain(..)
            .map(|p| Self::get_peer_value(p.0, p.2))
            .collect();
        Value::from_iter(peers)
    }

    fn get_icon(&mut self) -> String {
        get_icon()
    }

    fn remove_peer(&mut self, id: String) {
        PeerConfig::remove(&id);
    }

    fn remove_discovered(&mut self, id: String) {
        remove_discovered(id);
    }

    fn send_wol(&mut self, id: String) {
        crate::lan::send_wol(id)
    }

    fn new_remote(&mut self, id: String, remote_type: String, force_relay: bool) {
        new_remote(id, remote_type, force_relay)
    }

    fn is_process_trusted(&mut self, _prompt: bool) -> bool {
        is_process_trusted(_prompt)
    }

    fn is_can_screen_recording(&mut self, _prompt: bool) -> bool {
        is_can_screen_recording(_prompt)
    }

    fn is_installed_daemon(&mut self, _prompt: bool) -> bool {
        is_installed_daemon(_prompt)
    }

    fn get_error(&mut self) -> String {
        get_error()
    }

    fn is_login_wayland(&mut self) -> bool {
        is_login_wayland()
    }

    fn current_is_wayland(&mut self) -> bool {
        current_is_wayland()
    }

    fn get_software_update_url(&self) -> String {
        crate::SOFTWARE_UPDATE_URL.lock().unwrap().clone()
    }

    fn get_new_version(&self) -> String {
        get_new_version()
    }

    fn get_version(&self) -> String {
        get_version()
    }

    fn get_fingerprint(&self) -> String {
        get_fingerprint()
    }

    fn get_app_name(&self) -> String {
        get_app_name()
    }

    fn get_software_ext(&self) -> String {
        #[cfg(windows)]
        let p = "exe";
        #[cfg(target_os = "macos")]
        let p = "dmg";
        #[cfg(target_os = "linux")]
        let p = "deb";
        p.to_owned()
    }

    fn get_software_store_path(&self) -> String {
        let mut p = std::env::temp_dir();
        let name = crate::SOFTWARE_UPDATE_URL
            .lock()
            .unwrap()
            .split("/")
            .last()
            .map(|x| x.to_owned())
            .unwrap_or(crate::get_app_name());
        p.push(name);
        format!("{}.{}", p.to_string_lossy(), self.get_software_ext())
    }

    fn create_shortcut(&self, _id: String) {
        #[cfg(windows)]
        create_shortcut(_id)
    }

    fn discover(&self) {
        std::thread::spawn(move || {
            allow_err!(crate::lan::discover());
        });
    }

    fn get_lan_peers(&self) -> String {
        // let peers = get_lan_peers()
        //     .into_iter()
        //     .map(|mut peer| {
        //         (
        //             peer.remove("id").unwrap_or_default(),
        //             peer.remove("username").unwrap_or_default(),
        //             peer.remove("hostname").unwrap_or_default(),
        //             peer.remove("platform").unwrap_or_default(),
        //         )
        //     })
        //     .collect::<Vec<(String, String, String, String)>>();
        serde_json::to_string(&get_lan_peers()).unwrap_or_default()
    }

    fn get_uuid(&self) -> String {
        get_uuid()
    }

    fn open_url(&self, url: String) {
        #[cfg(windows)]
        let p = "explorer";
        #[cfg(target_os = "macos")]
        let p = "open";
        #[cfg(target_os = "linux")]
        let p = if std::path::Path::new("/usr/bin/firefox").exists() {
            "firefox"
        } else {
            "xdg-open"
        };
        allow_err!(std::process::Command::new(p).arg(url).spawn());
    }

    fn change_id(&self, id: String) {
        reset_async_job_status();
        let old_id = self.get_id();
        change_id_shared(id, old_id);
    }

    fn http_request(&self, url: String, method: String, body: Option<String>, header: String) {
        http_request(url, method, body, header)
    }

    fn post_request(&self, url: String, body: String, header: String) {
        post_request(url, body, header)
    }

    fn is_ok_change_id(&self) -> bool {
        hbb_common::machine_uid::get().is_ok()
    }

    fn get_async_job_status(&self) -> String {
        get_async_job_status()
    }

    fn get_http_status(&self, url: String) -> Option<String> {
        get_async_http_status(url)
    }

    fn t(&self, name: String) -> String {
        crate::client::translate(name)
    }

    fn is_xfce(&self) -> bool {
        crate::platform::is_xfce()
    }

    fn get_api_server(&self) -> String {
        get_api_server()
    }

    fn has_hwcodec(&self) -> bool {
        has_hwcodec()
    }

    fn has_vram(&self) -> bool {
        has_vram()
    }

    fn get_langs(&self) -> String {
        get_langs()
    }

    fn video_save_directory(&self, root: bool) -> String {
        video_save_directory(root)
    }

    fn handle_relay_id(&self, id: String) -> String {
        handle_relay_id(&id).to_owned()
    }

    fn get_login_device_info(&self) -> String {
        get_login_device_info_json()
    }

    fn support_remove_wallpaper(&self) -> bool {
        support_remove_wallpaper()
    }

    fn has_valid_2fa(&self) -> bool {
        has_valid_2fa()
    }

    fn generate2fa(&self) -> String {
        generate2fa()
    }

    pub fn verify2fa(&self, code: String) -> bool {
        verify2fa(code)
    }

    fn verify_login(&self, raw: String, id: String) -> bool {
        crate::verify_login(&raw, &id)
    }

    fn generate_2fa_img_src(&self, data: String) -> String {
        let v = qrcode_generator::to_png_to_vec(data, qrcode_generator::QrCodeEcc::Low, 128)
            .unwrap_or_default();
        let s = hbb_common::sodiumoxide::base64::encode(
            v,
            hbb_common::sodiumoxide::base64::Variant::Original,
        );
        format!("data:image/png;base64,{s}")
    }

    pub fn check_hwcodec(&self) {
        check_hwcodec()
    }

    fn is_option_fixed(&self, key: String) -> bool {
        crate::ui_interface::is_option_fixed(&key)
    }

    fn get_builtin_option(&self, key: String) -> String {
        crate::ui_interface::get_builtin_option(&key)
    }

    fn is_remote_modify_enabled_by_control_permissions(&self) -> String {
        match crate::ui_interface::is_remote_modify_enabled_by_control_permissions() {
            Some(true) => "true",
            Some(false) => "false",
            None => "",
        }
        .to_string()
    }
}

impl sciter::EventHandler for UI {
    sciter::dispatch_script_call! {
        fn t(String);
        fn get_api_server();
        fn is_xfce();
        fn using_public_server();
        fn is_custom_client();
        fn is_outgoing_only();
        fn is_incoming_only();
        fn is_disable_settings();
        fn is_disable_account();
        fn is_disable_installation();
        fn is_disable_ab();
        fn get_id();
        fn temporary_password();
        fn update_temporary_password();
        fn set_permanent_password(String);
        fn is_local_permanent_password_set();
        fn is_permanent_password_set();
        fn get_remote_id();
        fn set_remote_id(String);
        fn closing(i32, i32, i32, i32);
        fn get_size();
        fn new_remote(String, String, bool);
        fn send_wol(String);
        fn remove_peer(String);
        fn remove_discovered(String);
        fn get_connect_status();
        fn get_mouse_time();
        fn check_mouse_time();
        fn get_recent_sessions();
        fn get_peer(String);
        fn get_fav();
        fn store_fav(Value);
        fn recent_sessions_updated();
        fn get_icon();
        fn install_me(String, String);
        fn is_installed();
        fn get_supported_privacy_mode_impls();
        fn is_root();
        fn is_release();
        fn set_socks(String, String, String);
        fn get_socks();
        fn is_share_rdp();
        fn set_share_rdp(bool);
        fn is_installed_lower_version();
        fn install_path();
        fn install_options();
        fn goto_install();
        fn is_process_trusted(bool);
        fn is_can_screen_recording(bool);
        fn is_installed_daemon(bool);
        fn get_error();
        fn is_login_wayland();
        fn current_is_wayland();
        fn get_options();
        fn get_option(String);
        fn get_local_option(String);
        fn set_local_option(String, String);
        fn get_peer_option(String, String);
        fn peer_has_password(String);
        fn forget_password(String);
        fn set_peer_option(String, String, String);
        fn get_license();
        fn test_if_valid_server(String, bool);
        fn get_sound_inputs();
        fn set_options(Value);
        fn set_option(String, String);
        fn get_software_update_url();
        fn get_new_version();
        fn get_version();
        fn get_fingerprint();
        fn update_me(String);
        fn show_run_without_install();
        fn run_without_install();
        fn get_app_name();
        fn get_software_store_path();
        fn get_software_ext();
        fn open_url(String);
        fn change_id(String);
        fn get_async_job_status();
        fn post_request(String, String, String);
        fn is_ok_change_id();
        fn create_shortcut(String);
        fn discover();
        fn get_lan_peers();
        fn get_uuid();
        fn has_hwcodec();
        fn has_vram();
        fn get_langs();
        fn video_save_directory(bool);
        fn handle_relay_id(String);
        fn get_login_device_info();
        fn support_remove_wallpaper();
        fn has_valid_2fa();
        fn generate2fa();
        fn generate_2fa_img_src(String);
        fn verify2fa(String);
        fn check_hwcodec();
        fn verify_login(String, String);
        fn is_option_fixed(String);
        fn get_builtin_option(String);
        fn is_remote_modify_enabled_by_control_permissions();
    }
}

impl sciter::host::HostHandler for UIHostHandler {
    fn on_graphics_critical_failure(&mut self) {
        log::error!("Critical rendering error: e.g. DirectX gfx driver error. Most probably bad gfx drivers.");
    }
}

#[cfg(not(target_os = "linux"))]
fn get_sound_inputs() -> Vec<String> {
    let mut out = Vec::new();
    use cpal::traits::{DeviceTrait, HostTrait};
    let host = cpal::default_host();
    if let Ok(devices) = host.devices() {
        for device in devices {
            if device.default_input_config().is_err() {
                continue;
            }
            if let Ok(name) = device.name() {
                out.push(name);
            }
        }
    }
    out
}

#[cfg(target_os = "linux")]
fn get_sound_inputs() -> Vec<String> {
    crate::platform::linux::get_pa_sources()
        .drain(..)
        .map(|x| x.1)
        .collect()
}

// sacrifice some memory
pub fn value_crash_workaround(values: &[Value]) -> Arc<Vec<Value>> {
    let persist = Arc::new(values.to_vec());
    STUPID_VALUES.lock().unwrap().push(persist.clone());
    persist
}

pub fn get_icon() -> String {
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAARV0lEQVR4nO3dCXRV1b3H8X9CCJABCCEEkgBhCKOAiIwVBEvBiYdDK0qtVr2VIqsOT6vWVm1Zxdb65PFq7bOVtVSw9lUUuwoUafEBoszzIGJAIAiYkBDIQMj81j6BrrwsCMk9595zzv1/P2udBbq8Ozsx/9/Z55x99o5KzRxWKwBUina7AwDcQwAAihEAgGIEAKAYAQAoRgAAihEAgGIxosD82Hi3uwCfClSUSiSLirSJQBQ7Qi0QQaHg+wCg4OG2gI8DwZcBQNHDqwI+CwNfBQCFD78I+CQIPB8AFD38LuDhMPBsAFD4iDQBDwaBJ+cBUPyIRPM9+DjaUyMAL/6AgEgeDXgiACh8aBVwOQhcvwSg+KHZfJdHvdGav3nAC9ysA1cuASh8wBuXBGEfAVD8gHfqI6wBQPED3qqTsAUAxQ94r17CEgAUP+DNugl5AFD8gHfrJ6QBQPED3q6jkAUAxQ94v55CEgAUP+CPunI8ACh+IHScri/X3wUA4B5HA4CzPxB6TtaZYwFA8QPh41S9ORIAFD8Qfk7UHfcAAMVsBwBnf8A9duuPEQCgmK0A4OwPuM9OHQYdABQ/4B3B1iOXAIBiQQUAZ3/Ae4KpS0YAgGIEAKBYswOA4T/gXc2tT0YAgGLNCgDO/oD3NadOGQEAihEAgGJNDgCG/4B/NLVeGQEAihEAgGIEAKBYkwKA63/Af5pSt4wAAMUIAEAxAgBQjAAAFLtsAHADEPCvy9UvIwBAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUCzG7Q5EiqgWLaTdgCxJ6J0pcRld6o70zhKbnCQtWreSFm1aW39Gt4qV2qpqqSmvkOqKCqkuLZPyglNSfvKUnMs/JaWHcqT4wGEpzj4s5ScL3P62EOEIABvaDxkgqRPGSIdhg6T9oH5WkTdFVGy0RMe2lBiJF0lOkrhuaRf978pO5EnBph1SsHG75K1eL+UFheKmtJu+KVfNfc5WG0v7XutYf2AfAdBMplgzbrleMqZ865KF65Q2XTpJxtRJ1lFbXSP567fKsb/9Q47/fZXUVFaG9GtDBwKgieK7p0vWrO9L+s0TJapF+G+dmK+Zcs1w6+j3xAw59OYiOfzOX6W67FzY+4LIwU3Ay4hJiJfBs5+Q8cvfts7EbhR/Q607dZT+T86UCR++LV0mM6RG8Nz/bfawDsOHyLVL3pBu06Z4ovAbat05RYb9drZc/eovJSax8T3ggIvx3m+1R/QK3CWjF8yTNmmp4nWdJ46Vse+/LolZPdzuCnyGALiIvo8GpP+PfyhR0dG+ukcx5p1XpN0Vfd3uCnzEP7/hYWIKP2vm98SPWrZNlNFv/qe0G9jH7a7AJwiAetJumGAN/f3M3AsY/tqvrBuFwOUQAOcl9Ogmg+c8KZHAFL+5MWhmJwKNIQDOG/zCkxITHyeRov3g/tL7weludwMeRwCISJfJ46XDVYMk0mQ9dK81sgEuRX0AmGFy/ydmSCQy7xv0eeR+t7sBD1M/FTj1ujGOz+kvzy+U/A3bpOjzA1K074CUnciVqpJSqSo5K9XnzlmXGmaGYcvEBEnMypS2/bMkacgA6XD1YJGoKEf7knb9eMnu01OKv/jS0XYRGdQHQLdv3+TMT7K2Vo4vXyVHFy+X/HVbrJd3LqWyqMQ6yiRXivYflGNLP7L+vZl01PXW66Xn/dOsgHBEVJRkTr9Fdv98rjPtIaKovgRolZwkKWNH2m7n9M7P5JM7Zsq2x34hJ9duarT4G1N2PFe+ePUtWX3jPZL7v5+KU8wLTGYdAqAh1QFghtx25/jnvLtUPr1rlpzetc+xfp3LzZfND/1UvvrgQ8fmBnS6ZoQjbSGyqA6ApCsH2vr8yU82y65nXwr6jN+o2lrZ+cyLkrdmgyPNdfzG1Y60g8iiOgDMKj527J3zWwml2poa2f38y468899x9DBH+oTIojoAWnVKDvqz5uZdyZc5EmpmWbDs1xbabic+M8NakxCoT3UAtGzXNujPnj1yTMLF3Georaqy1YZ5szGhJ5OC8P/pDoDEhKA/W1tbK+FSceq05K5ab7uduG7pjvQHkUN1ANRUVAT92YQeXSWcvv7nx7bbaNWhvSN9QeRQHQBVpWVBfzaxT8+wrsBTuGOv7TZik9o50hdEDtUzAc/lnpRWHZOC/vzAZ34kG+77dwmH0iPHrPkBZkJPlZlJWFx31P29VCqLi+v9veSi/42ZjgzUpzoAzF18O6vndBwzTK547lHZM3uehMPKcbeH5etAD9WXAEX7sm23kfndW+tW4EllBR74j+oAOLluiyPtmO3BJqz4kwx4epa1mw/gF6oDoOjzg9Z1tRPMvoA977tDrvvoLzLijy9a6ws2da9AwC2q7wGY+fZH3/+7ZD10j2NNmpeLOl07yjrMFF7zdmDu6nWSt2ajlOefcuzrAE7QHQBmlt2ipdbaeVExzv8ozAig86Rx1mHCpjj7kLXBZ/6G7VK4bbdUnC5y/GsCzaE+AMw7+DmLlkn3u6ZKSEVF1c0d6NNTetz7nbpAOHhECrfullNbd8mpLbvk7LGvQ9sHoAH1AWCYRTjSp0x0bhWepgZC70zrMHsPXggjs5RYwcbt1qvGXDIg1AgAs4bfyQLZ+8LvZMgLT4mbrCXBbrvBOgyzpqBZDyB31To5vXOf9Xow4CQC4DxzM9DcuPPSdttt+/W2jt4z7rZGAydWrJHjyz6SU9v2WJcQgF0EQD07nnpB4rqmSbsBWeI1rTp2sCYdmePs0ePW4qPmNWEuE2CH6nkADZnHdptnPC0lh0K/0IcdJqT6PvKATFyzSK588Rne80fQCIAGzuXly/q7H5HiA4fF68yjy4xbJsu1S9+y3kkwuwMDzUEAXIQZVn9650OOLcgZambykbk0mLDibUmf8i23uwMfIQAuoaq4VDb/8Ceyd84rjizKGQ6xHdrL0P/4mVzx/GMS3bKl292BDxAAjTCP3Q4teM/aqMPavccnd97NTkCjF86z9gMAGkMANIGZoLP98dmy9rYfyIkPV4dmHwCHJQ29Qka+/pLExLVxuyvwMAKgGc58li1bH3leVk3+rhyc/2cpLygUL0saOlCG/+HXIXnPAZGBAAiCeQ6/76XXZOW4b8vmmc/IsSUrpeps8OsLhlLyiCul32MBt7sBj+LUYINZq99s4mkOs1af2X0ndfxoa0ahmdbrFb0euNN6C9G8XwDURwA4pKa8QvJWr7cOI757hiSPGiodRw61zsKtUoLfhci2qCgZ9IvHZdXku21vMILIQgCESOmRr6wj5y9L/hUIZjdiEwbmCPcIIS6ji3SfNkUO/+mDsH5deBsBEOZAMC8dGSYAkkeeHyGMHBqWQDArH5kFUGoqKkP+teAPBICLjxa/+uBD67gwQki5ZrikjB1h3UsIxUae5oWiTuNGydcr1zreNvyJAPDYCMEM0a2lxCaOlW7fuckaHTipyw0TCAD8C48BPchMPT625J+y/p5HZe1tD1oLizol9boxEh3LNGHUIQA87sze/bIx8GNrrQLzpMEuMzMwMaunI32D/xEAPvHVX1fIpgefktrqatttte3Xy5E+wf+4B9DwB5IYL3HpXSQuvbO0Se8scV271P1p/jmts6yaNF0qCs+48j/LLBia/fsF0udH99lqxywzBqgMgJj4uLqCzjDHheI+/2dGF2nZNqHRz7cf3N/VdQK+fONd6Xn/NOv7CFabNLYvg9IAGLv4jxKf2TXoz3ccdZWrAVBVelYKNu6wbuYFK6zLn8PTojVuCW5Hp/GjxW121yxsyToBOI8AaKaEnt2kbX93r6FrK+3N52/RhjUCoDQAivZl226j2x11O/m4xe41vLmMAFQGwKmtu223YXbuMevvuSWxr73HeJVsSgqtAVB2Is+ah2+Hmadv91Gcrd2CbAYAuxJDbQAYZnEMu7pP+zdrya1w6/WD6bbbKDno/T0PEB4qA+DEPz52ZC3+oS8/F9ZLgc6Txkn6zd+03U7h9r2O9Af+pzIA8j/dYq37b5eZHTjiD7++7OQhJ7QfMkCGzLG/e7FZ0fj0rn2O9An+pzIAaior5djSlY60ZWYGjnnnd5KY1UNCxbwSPOqNlx0JmsJtuz27gCnCT2UAGIcWvu9YW6b4x37wumTN/J5EtWjhWLtmxp7Z82/Um3NtTf2tL+e9ZY60g8igbirwBSUHj8jJTzZJyjUjHGnPbMXV99GAdL9zquS8u0RyFi2zNhoNdrKR2fSz6+03Wqv4OKWqpFROrFjjWHvwP7UBYHw+d76kfGO4tWquU1p3TpE+D98vWbPulTN79kvhzn1yetdnUvLlUaksKpbKohKrEM2iHOYM3zIhXmKT21uP9swMw/aD+oXsbT1z9nd7n8Ob93s7gHLeWya7fvob0SJG+2IbZs+/9CkTHW/bXAqYG3fmELld3GbCJ/v3C93uBjxG7T2AC/b95r+l8kyRRLrsVxeo+D7RPOoDwFyn735+rkSyon0H2A8AF6U+AIzjy1fJkf/5m0QiM99hy8PPWo8+gYYIgPP2zJ4XkXvn7Xj6V3I257jb3YBHEQDnmcU2zdbfhdv3SESorZU9v/wv9gBAowiAeszjuQ33PW7ND/AzM9135zMvyuGFi93uCjyOAGjAPCffNOMncmjBe+JHZp7B1oefk6OLl7vdFfgAAXARZgvtvXNekS2zfubaEuDByF+3VdZM+T7DfjSZ6olAl2M20SzYtF36PvyAdJ8+1dF5/k4qP1kgX7z6Vt2TjNpat7sDHyEAmjCkNjfTDr29WHo9cKdkTJ0k0a1ixSurGx2c/+e6Lb8d2DYM+hAATVR6+KjsevYl2T9vvmTcer2k3XidtBvYR8LNvMqbt2qdNXchb/UGnu/DFgKgmcoLCq2zrjniu6dLyriRkjz8SkkePiQkqwOZM/uZz7KtF4oKNu2UvLUbOdvDMVGpmcMavWicH8suMk3VJi1VEntnSkLvTInvniGtUjpI644dJDY5yXqf37wBaB0xMVJTUSnV5eVSXVYu1efKpfpsmTUt2SxYemHhUrOJSdH+g9ZNSSBYgYpLr37FCMBBVvEez5W8jzc62SwQMjwGBBQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUIwAABQjAADFCABAMQIAUOyyARCoKA1PTwA47nL1ywgAUIwAABQjAADFCABAsSYFADcCAf9pSt0yAgAUIwAAxQgAQLEmBwD3AQD/aGq9MgIAFCMAAMWaFQBcBgDe15w6ZQQAKNbsAGAUAHhXc+uTEQCgGAEAKBZUAHAZAHhPMHXJCABQLOgAYBQAeEew9WhrBEAIAO6zU4dcAgCK2Q4ARgGAe+zWHyMAQDFHAoBRABB+TtSdYyMAQgAIH6fqzdFLAEIACD0n64x7AIBijgcAowAgdJyur5CMAAgBwB91FbJLAEIA8H49hfQeACEAeLuOQn4TkBAAvFs/YXkKQAgA3qybsD0GJAQA79VLWOcBEAKAt+ok7BOBCAHAO/URlZo5rFZcMj823q0vDXiKWydGV6cCMxoAxNU6cP1dAEIAmgVcLH7XLwEa4pIAWgRcLnxPBsAFBAEiVcAjhe+ZSwA//JCASP299uQIoD5GA/C7gAcL3zcBUB9hAL8IeLjofRsAFxAE8KqATwrf1wFQH2EAtwV8VvQRFQANEQgItYCPCz7iA+BiCAUEKxBBxa42AAD4aB4AgPAgAADFCABAMQIAUIwAABQjAADR6/8AzTtH3iEq/YIAAAAASUVORK5CYII=".to_owned()
}
