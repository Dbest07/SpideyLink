pub const VERSION: &str = "1.5.1";
#[allow(dead_code)]
pub const BUILD_DATE: &str = "2026-10-19 04:07";
