use hbb_common::config;

pub fn locally_approved(clicked: bool) -> bool {
    clicked
}

pub fn initialize() -> bool {
    *config::APP_NAME.write().unwrap() = "Spidey Link".to_owned();
    if std::env::args().skip(1).any(|arg| matches!(arg.as_str(),
        "--install" | "--service" | "--tray" | "--run-as-system" | "--elevate")) {
        return false;
    }
    let mut hard = config::HARD_SETTINGS.write().unwrap();
    for key in ["disable-installation", "disable-account", "disable-ab", "disable-settings"] {
        hard.insert(key.to_owned(), "Y".to_owned());
    }
    drop(hard);
    let mut options = config::OVERWRITE_SETTINGS.write().unwrap();
    for (key, value) in [
        ("approve-mode", "click"),
        ("verification-method", "use-temporary-password"),
        ("allow-hide-cm", "N"),
        ("enable-block-input", "N"),
        ("allow-logon-screen-password", "N"),
        ("allow-auto-disconnect", "Y"),
        ("allow-remote-config-modification", "N"),
    ] {
        options.insert(key.to_owned(), value.to_owned());
    }
    true
}

#[cfg(test)]
mod tests {
    #[test]
    fn incoming_sessions_require_local_approval() {
        hbb_common::config::OVERWRITE_SETTINGS.write().unwrap().insert("approve-mode".into(), "password".into());
        assert!(super::initialize());
        assert_eq!(hbb_common::password_security::approve_mode(), hbb_common::password_security::ApproveMode::Click);
        assert!(hbb_common::config::is_disable_installation());
        assert!(!hbb_common::password_security::hide_cm());
        assert!(!super::locally_approved(false));
        assert!(super::locally_approved(true));
    }
}

#[derive(serde_derive::Deserialize)]
struct ServerProfile {
    id_server: String,
    relay_server: String,
    key: String,
}

pub fn configure_server() -> bool {
    let result = (|| -> hbb_common::ResultType<()> {
        let exe = std::env::current_exe()?;
        let folder = exe.parent().ok_or_else(|| hbb_common::anyhow::anyhow!("Missing app folder"))?;
        let profile: ServerProfile = serde_json::from_str(&std::fs::read_to_string(folder.join("spidey-server.json"))?)?;
        if profile.id_server.trim().is_empty() || profile.relay_server.trim().is_empty() || profile.key.len() != 44 {
            hbb_common::bail!("Incomplete Spidey Link server profile");
        }
        *config::EXE_RENDEZVOUS_SERVER.write().unwrap() = profile.id_server.clone();
        let mut options = config::OVERWRITE_SETTINGS.write().unwrap();
        options.insert("custom-rendezvous-server".into(), profile.id_server);
        options.insert("relay-server".into(), profile.relay_server);
        options.insert("key".into(), profile.key);
        options.insert("api-server".into(), String::new());
        Ok(())
    })();
    if let Err(err) = result {
        #[cfg(windows)]
        crate::platform::message_box(&format!("Spidey Link server configuration could not be loaded: {err}"));
        return false;
    }
    true
}
