use std::{
    sync::{
        atomic::{AtomicBool, AtomicU64, Ordering},
        Once, OnceLock,
    },
    time::Instant,
};
use winapi::{
    shared::minwindef::{LPARAM, LRESULT, WPARAM},
    um::{libloaderapi::GetModuleHandleW, winuser::*},
};

const LOCAL_PRIORITY_MS: u64 = 2_000;
const EXIT_HOTKEY_ID: i32 = 0x5350;
static CLOCK: OnceLock<Instant> = OnceLock::new();
static MOUSE_START: Once = Once::new();
static EXIT_START: Once = Once::new();
static MOUSE_READY: AtomicBool = AtomicBool::new(false);
static MOUSE_ENABLED: AtomicBool = AtomicBool::new(false);
static MOUSE_POLICY: MousePolicy = MousePolicy::new();

struct MousePolicy {
    last_local: AtomicU64,
}

impl MousePolicy {
    const fn new() -> Self {
        Self {
            last_local: AtomicU64::new(0),
        }
    }

    fn observe(&self, injected: bool, now: u64) {
        if !injected {
            self.last_local.store(now, Ordering::SeqCst);
        }
    }

    fn allows(&self, now: u64, ready: bool, release: bool) -> bool {
        // Never drop a remote button release and leave a drag/button stuck down.
        if release {
            return true;
        }
        let last = self.last_local.load(Ordering::SeqCst);
        ready && (last == 0 || now.saturating_sub(last) >= LOCAL_PRIORITY_MS)
    }
}

fn clock_ms() -> u64 {
    CLOCK.get_or_init(Instant::now).elapsed().as_millis() as u64 + 1
}

unsafe extern "system" fn mouse_hook(code: i32, message: WPARAM, data: LPARAM) -> LRESULT {
    if code >= 0 && MOUSE_ENABLED.load(Ordering::SeqCst) && data != 0 {
        let event = &*(data as *const MSLLHOOKSTRUCT);
        MOUSE_POLICY.observe(event.flags & LLMHF_INJECTED != 0, clock_ms());
    }
    CallNextHookEx(std::ptr::null_mut(), code, message, data)
}

pub fn start_mouse_priority() {
    if !MOUSE_ENABLED.swap(true, Ordering::SeqCst) {
        MOUSE_POLICY.last_local.store(0, Ordering::SeqCst);
    }
    MOUSE_START.call_once(|| {
        if let Err(err) = std::thread::Builder::new()
            .name("spidey-mouse-priority".into())
            .spawn(|| unsafe {
                let hook = SetWindowsHookExW(
                    WH_MOUSE_LL,
                    Some(mouse_hook),
                    GetModuleHandleW(std::ptr::null()),
                    0,
                );
                if hook.is_null() {
                    hbb_common::log::error!(
                        "Local mouse priority could not start: {}",
                        std::io::Error::last_os_error()
                    );
                    return;
                }
                MOUSE_READY.store(true, Ordering::SeqCst);
                let mut message: MSG = std::mem::zeroed();
                while GetMessageW(&mut message, std::ptr::null_mut(), 0, 0) > 0 {
                    TranslateMessage(&message);
                    DispatchMessageW(&message);
                }
                MOUSE_READY.store(false, Ordering::SeqCst);
                UnhookWindowsHookEx(hook);
            })
        {
            hbb_common::log::error!("Local mouse priority thread could not start: {err}");
        }
    });
}

pub fn stop_mouse_priority() {
    MOUSE_ENABLED.store(false, Ordering::SeqCst);
}

pub fn allow_remote_mouse(release: bool) -> bool {
    MOUSE_POLICY.allows(
        clock_ms(),
        MOUSE_READY.load(Ordering::SeqCst) && MOUSE_ENABLED.load(Ordering::SeqCst),
        release,
    )
}

pub fn start_exit_shortcut() {
    EXIT_START.call_once(|| {
        if let Err(err) = std::thread::Builder::new()
            .name("spidey-end-session".into())
            .spawn(|| unsafe {
                if RegisterHotKey(
                    std::ptr::null_mut(),
                    EXIT_HOTKEY_ID,
                    (MOD_CONTROL | MOD_SHIFT | MOD_NOREPEAT) as u32,
                    VK_F11 as u32,
                ) == 0
                {
                    hbb_common::log::warn!(
                        "End-session shortcut is unavailable: {}",
                        std::io::Error::last_os_error()
                    );
                    return;
                }
                let mut message: MSG = std::mem::zeroed();
                while GetMessageW(&mut message, std::ptr::null_mut(), 0, 0) > 0 {
                    if message.message == WM_HOTKEY && message.wParam == EXIT_HOTKEY_ID as usize {
                        crate::ui_cm_interface::end_spidey_desktop_sessions();
                    }
                }
                UnregisterHotKey(std::ptr::null_mut(), EXIT_HOTKEY_ID);
            })
        {
            hbb_common::log::error!("End-session shortcut thread could not start: {err}");
        }
    });
}

#[cfg(test)]
mod tests {
    use super::MousePolicy;

    #[test]
    fn physical_activity_blocks_remote_input_until_two_seconds_of_idle() {
        let policy = MousePolicy::new();
        assert!(policy.allows(1, true, false));
        policy.observe(false, 1_000);
        assert!(!policy.allows(2_999, true, false));
        policy.observe(false, 2_000);
        assert!(!policy.allows(3_999, true, false));
        assert!(policy.allows(4_000, true, false));
    }

    #[test]
    fn injected_events_do_not_extend_local_priority() {
        let policy = MousePolicy::new();
        policy.observe(false, 1_000);
        policy.observe(true, 2_999);
        assert!(policy.allows(3_000, true, false));
    }

    #[test]
    fn releases_are_kept_but_unready_monitor_blocks_new_input() {
        let policy = MousePolicy::new();
        assert!(!policy.allows(100, false, false));
        assert!(policy.allows(100, false, true));
        policy.observe(false, 100);
        assert!(policy.allows(101, true, true));
        assert!(!policy.allows(101, true, false));
    }
}
